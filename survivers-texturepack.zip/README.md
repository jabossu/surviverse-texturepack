# Surverse texturepack

> Ce petit texturepack a l'ambition de proposer aux survivors des textures alternatives pour aller de paire avec le datapack [custom_roleplay_data_v1.0](https://www.curseforge.com/minecraft/customization/custom-roleplay-data-datapack)  
> -- Topaway

### Tutorial I used to create the texturepack
 - [How to use Custom Model Data in Minecraft!](https://www.youtube.com/watch?v=HrFMdcjonyo)
 - [How To Get Hermitcraft Custom Models on Your Minecraft Server!](https://www.youtube.com/watch?v=dtcZhtZ0PqI)
